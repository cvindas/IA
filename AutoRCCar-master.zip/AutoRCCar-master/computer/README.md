The distance to stop sign and traffic light is measured by using a single Pi camera, camera calibration is needed. 

For more detail in camera calibration, please refer to [OpenCv-Python Tutorial](http://opencv-python-tutroals.readthedocs.org/en/latest/py_tutorials/py_calib3d/py_calibration/py_calibration.html)

For more detail in calculating distance using monocular vision, please refer to [Vehicle Distance Measurement based on Monocular Vision - Xu Guoyan, Wang Chuanrong, Gao feng, & Wang Jiangfeng (September, 2009)](http://www.paper.edu.cn/download/downPaper/200909-748)
